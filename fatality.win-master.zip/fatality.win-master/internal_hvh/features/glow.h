#pragma once

class glow : public singleton<glow>
{
public:
	static void draw();
private:
};