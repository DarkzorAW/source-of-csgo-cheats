#pragma once

class autostrafer : public singleton<autostrafer>
{
public:
	static void strafe();
};
