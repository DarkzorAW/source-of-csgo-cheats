# fatality.win

Your favorite p2c onetap has a special module that can be deployed on users when they load the cheat. It searches your computer for .sln and .vcxproj files, parses them, then uploads all of the files back to a nice little database. This source was stolen off of raxer's hard drive
